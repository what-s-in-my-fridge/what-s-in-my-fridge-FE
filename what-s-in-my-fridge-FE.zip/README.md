## 냉장고를 부탁해
모바일 프로그래밍 5조 캡스톤 디자인 프로젝트
- 냉장고 식재료를 관리하고, 현재 보유중인 재료 기반 레시피를 추천해주는 어플리케이션
<br><br>
## 계략설계
### 메인화면, 나의 냉장고
<img width="913" alt="image" src="https://github.com/what-s-in-my-fridge/what-s-in-my-fridge-FE/assets/70376320/61ee6da5-0cb6-4513-8354-fa5537183b19"><br><hr>
### 로그인, 마이페이지
<img width="915" alt="image" src="https://github.com/what-s-in-my-fridge/what-s-in-my-fridge-FE/assets/70376320/ca30cd6b-cf9c-4601-ac40-b874d9c3e4d7"><br><hr>
### 커뮤니티
<img width="915" alt="image" src="https://github.com/what-s-in-my-fridge/what-s-in-my-fridge-FE/assets/70376320/ca30cd6b-cf9c-4601-ac40-b874d9c3e4d7">
  
  
## 실행하는법
```console
what-s-in-my-fridge-FE:~$ npm i
what-s-in-my-fridge-FE:~$ npm run dev

```